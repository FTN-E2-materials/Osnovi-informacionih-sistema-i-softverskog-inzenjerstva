"""
    More on: https://www.geeksforgeeks.org/selection-sort/
"""

from util import timeit, test_sort


def selection_sort(arr):
    for i in range(len(arr) - 1):
        min_idx = i
        # find minumum in unsorted part of array
        for j in range(i + 1, len(arr)):
            if arr[j] < arr[min_idx]:
                min_idx = j
        # swap if needed
        if min_idx != i:
            arr[i], arr[min_idx] = arr[min_idx], arr[i]


@timeit
def wrap_selection_sort(arr):
    selection_sort(arr)


if __name__ == "__main__":
    test_sort(wrap_selection_sort)
