"""
    More on: https://www.geeksforgeeks.org/insertion-sort/
"""

from util import timeit, test_sort


def insertion_sort(input_array):
    for i in range(len(input_array)):
        key = input_array[i]
        j = i - 1
        # Move elements of arr[0..i-1], that are
        # greater than key, to one position ahead
        # of their current position
        while j >= 0 and input_array[j] > key:
            input_array[j + 1] = input_array[j]
            j -= 1
        input_array[j + 1] = key


@timeit
def wrap_insertion_sort(arr):
    insertion_sort(arr)


if __name__ == "__main__":
    test_sort(wrap_insertion_sort)
