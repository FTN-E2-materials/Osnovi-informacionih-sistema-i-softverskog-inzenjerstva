"""
Modul sadrži implementaciju quick sort algoritma

Dodatna objašnjenja se mogu pronaći na sledećem linku: https://www.geeksforgeeks.org/quick-sort/
"""
import random

from util import test_sort, timeit


def partition(arr, left, right):
    """
    Funkcija vrši particionisanje niza nad zadatim intervalom

    Particionisanje niza vrši se dovođenjem elemenata u takav
    redosled da su svi elementi manji ili jednaki pivotu levo
    od njega, dok se elementi veći od pivota dovode na pozicije
    desno od njega.

    Argumenti:
    - `arr`: niz koji se particioniše
    - `left`: indeks krajnjeg levog elementa
    - `right`: indeks krajnjeg desnog elementa
    """
    # poslednji element postaje pivot
    pivot = arr[right]

    # varijabla čuva indeks poslednjeg elementa manjeg od pivota
    i = left - 1

    for j in range(left, right):
        if arr[j] <= pivot:
            i = i + 1
            arr[i], arr[j] = arr[j], arr[i]

    i = i + 1
    arr[i], arr[right] = arr[right], arr[i]
    return i


def quick_sort(arr, left, right):
    """
    Quick sort algoritam

    Argumenti:
    - `arr`: niz koji se sortira
    - `left`: indeks krajnjeg levog elementa
    - `right`: indeks krajnjeg desnog elementa
    """
    if left < right:
        pivot = partition(arr, left, right)
        quick_sort(arr, left, pivot - 1)
        quick_sort(arr, pivot + 1, right)


def random_partition(arr, left, right):
    """
    Funkcija vrši particionisanje niza nad zadatim intervalom

    Pre samog particionisanja niza, unosi se `šum` zamenom poslednjeg
    elementa niza (pivota) i nasumično odabranog elementa u nizu.

    Argumenti:
    - `arr`: niz koji se particioniše
    - `left`: indeks krajnjeg levog elementa
    - `right`: indeks krajnjeg desnog elementa
    """
    i = random.randrange(left, right)
    arr[right], arr[i] = arr[i], arr[right]
    return partition(arr, left, right)


def random_quick_sort(arr, left, right):
    """
    Quick sort uz randomized particionisanje

    Argumenti:
    - `arr`: niz koji se sortira
    - `left`: indeks krajnjeg levog elementa
    - `right`: indeks krajnjeg desnog elementa
    """
    if left < right:
        pivot = random_partition(arr, left, right)
        random_quick_sort(arr, left, pivot - 1)
        random_quick_sort(arr, pivot + 1, right)


def tail_sort(arr, left, right):
    """
    Quick sort, jedan rekurzivni poziv manje

    Argumenti:
    - `A`: niz koji se sortira
    - `left`: indeks krajnjeg levog elementa
    - `right`: indeks krajnjeg desnog elementa
    """
    while left < right:
        pivot = random_partition(arr, left, right)
        tail_sort(arr, left, pivot - 1)
        left = pivot + 1


@timeit
def wrap_quick_sort(arr):
    quick_sort(arr, 0, len(arr) - 1)


@timeit
def wrap_random_quick_sort(arr):
    random_quick_sort(arr, 0, len(arr) - 1)


@timeit
def wrap_tail_sort(arr):
    tail_sort(arr, 0, len(arr) - 1)


def worst_case_test():
    n = 100
    wrap_quick_sort(list(range(n)))
    wrap_random_quick_sort(list(range(n)))
    wrap_tail_sort(list(range(n)))


if __name__ == '__main__':
    test_sort(wrap_quick_sort)
    test_sort(wrap_random_quick_sort)
    test_sort(wrap_tail_sort)
    worst_case_test()
