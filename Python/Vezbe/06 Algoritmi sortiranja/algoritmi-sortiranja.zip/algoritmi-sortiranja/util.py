from random import randint
import time
from functools import wraps


def generate_array(n=10, min_int=1, max_int=100):
    return [randint(min_int, max_int) for x in range(n)]


def test_sort(func):
    print()
    arr = generate_array(10, 1, 100)
    print("Initial array:", arr)
    func(arr)
    print("Sorted array (%s sort):" % func.__name__, arr)
    print()


def timeit(method):
    @wraps(method)
    def timed(*args, **kw):
        ts = time.time()
        result = method(*args, **kw)
        te = time.time()
        if 'log_time' in kw:
            name = kw.get('log_name', method.__name__.upper())
            kw['log_time'][name] = int((te - ts) * 1000)
        else:
            print('Function: %r  Execution time: %2.2f ms' %
                  (method.__name__, (te - ts) * 1000))
        return result

    return timed
