from random import shuffle

from bubble_sort import wrap_bubble_sort
from bucket_sort import wrap_bucket_sort, wrap_bucket_sort_cheat
from heap_sort import wrap_heap_sort
from insertion_sort import wrap_insertion_sort
from merge_sort import wrap_merge_sort
from quick_sort import wrap_tail_sort
from selection_sort import wrap_selection_sort
from util import generate_array


def sort_test(arr, sort_func):
    shuffle(arr)
    sort_func(arr)


def main():
    input_array = generate_array(1000, 1, 100)
    sort_test(input_array, wrap_bubble_sort)
    sort_test(input_array, wrap_selection_sort)
    sort_test(input_array, wrap_insertion_sort)

    sort_test(input_array, wrap_heap_sort)
    sort_test(input_array, wrap_merge_sort)
    sort_test(input_array, wrap_tail_sort)

    sort_test(input_array, wrap_bucket_sort)
    sort_test(input_array, wrap_bucket_sort_cheat)


if __name__ == "__main__":
    main()
