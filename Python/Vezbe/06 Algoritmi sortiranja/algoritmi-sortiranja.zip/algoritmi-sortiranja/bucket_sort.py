"""
Bucket Sort is mainly useful when input is uniformly distributed over a range.

More on: https://www.geeksforgeeks.org/heap-sort/
"""

from util import test_sort
from quick_sort import tail_sort
from util import timeit


def find_key(number):
    # We need to know distribution of values in array.
    # Assume following:
    # 1. 10 buckets
    # 2. max number in array is <= 100
    return number // 10 if number < 100 else 9


def bucket_sort(arr):
    # 10 buckets
    buckets = [[] for _ in range(10)]

    for _ in range(len(arr)):
        el = arr.pop()
        # add element in corresponding bucket
        buckets[find_key(el)].append(el)

    for b in buckets:
        # sort each bucket
        tail_sort(b, 0, len(b) - 1)
        # add sorted elements to original array
        arr.extend(b)

    return arr


def bucket_sort_cheat(arr, max_number):
    buckets = [[] for _ in range(max_number + 1)]
    for _ in range(len(arr)):
        el = arr.pop()
        buckets[el].append(el)

    for b in buckets:
        # no need to sort elements
        arr.extend(b)

    return buckets


@timeit
def wrap_bucket_sort(arr):
    bucket_sort(arr)


@timeit
def wrap_bucket_sort_cheat(arr):
    bucket_sort_cheat(arr, 100)


if __name__ == "__main__":
    test_sort(wrap_bucket_sort)
    test_sort(wrap_bucket_sort)
