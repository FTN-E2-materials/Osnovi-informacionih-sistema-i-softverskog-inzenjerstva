BASE = 16
DIGITS = "0123456789ABCDEF"


def convert(broj):
    if broj<BASE:
        return DIGITS[broj]

    return str(convert(broj//BASE)) + str(DIGITS[broj%BASE])


if __name__ == '__main__':
    broj = 5728
    print(convert(broj))

