"""
Program izračunava maksimalni element liste rekurzivnim putem.
"""


def find_max_with_len(seq, n):
    """
    Funkcija izračunava maksimalni element liste rekurzivnim putem.

    Argumenti:
    - `seq`: lista čiji maksimum se traži
    - `n`: broj preostalih elemenata za poređenje
    """

    # bazni slučaj
    if n == 1:
        return seq[0]
    else:
        max_remaining_el = find_max_with_len(seq, n-1)
        if max_remaining_el > seq[n-1]:
            return max_remaining_el
        else:
            return seq[n-1]


def find_max(seq):
    """
    Funkcija izračunava maksimalni element liste rekurzivnim putem.

    Argumenti:
    - `seq`: lista čiji maksimum se traži
    - `n`: broj preostalih elemenata za poređenje
    """

    # bazni slučaj
    if len(seq) == 1:
        return seq[0]
    else:
        max_remaining_el = find_max(seq[1:])
        if max_remaining_el > seq[1]:
            return max_remaining_el
        else:
            return seq[1]

if __name__ == '__main__':
    seq = [88, 2, 123, 4, 11, 10, 19]
    print(find_max_with_len(seq, len(seq)))
    print(find_max(seq))

