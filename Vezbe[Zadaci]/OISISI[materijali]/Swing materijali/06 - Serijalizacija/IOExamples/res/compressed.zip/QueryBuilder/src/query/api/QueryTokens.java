package query.api;

public class QueryTokens {

	public static final String BETWEEN = "BETWEEN";
	public static final String DELIMITER = " ";
	public static final String EQUALS = "=";
	public static final String WHERE = " WHERE ";
	public static final String ALL_FROM = "* FROM";
	public static final String AND = " AND ";
	public static final String FINAL = ";";
	
}
