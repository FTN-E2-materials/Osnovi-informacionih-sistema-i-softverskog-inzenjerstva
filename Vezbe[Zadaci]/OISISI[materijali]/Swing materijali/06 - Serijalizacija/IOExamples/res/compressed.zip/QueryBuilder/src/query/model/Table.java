package query.model;

public class Table {

	private String name;
	
	public Table(String name) { this.name = name; }
	
	public String getName() { return this.name; }
	
}
