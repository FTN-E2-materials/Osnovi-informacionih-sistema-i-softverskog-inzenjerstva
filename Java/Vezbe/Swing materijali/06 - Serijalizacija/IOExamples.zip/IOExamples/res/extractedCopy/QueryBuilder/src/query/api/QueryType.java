package query.api;

public enum QueryType {

	SELECT,
	DELETE,
	INSERT,
	UPDATE
	
}
