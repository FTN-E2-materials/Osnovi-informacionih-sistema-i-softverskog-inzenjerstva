package query.model;

public enum Operator {
	AND,
	OR,
	NOT
}
