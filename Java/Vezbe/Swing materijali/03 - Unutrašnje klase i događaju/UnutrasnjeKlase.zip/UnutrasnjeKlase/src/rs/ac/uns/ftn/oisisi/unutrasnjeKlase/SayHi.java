package rs.ac.uns.ftn.oisisi.unutrasnjeKlase;

public interface SayHi {
	
	void sayHi();

}
