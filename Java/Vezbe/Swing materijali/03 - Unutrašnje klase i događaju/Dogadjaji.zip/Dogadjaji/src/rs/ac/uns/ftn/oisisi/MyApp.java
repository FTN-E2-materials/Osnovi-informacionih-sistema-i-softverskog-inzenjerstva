package rs.ac.uns.ftn.oisisi;

public class MyApp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MainFrame mf = new MainFrame();
	    mf.setVisible(true); // Prozor je inicijalno nevidljiv

	}

}
