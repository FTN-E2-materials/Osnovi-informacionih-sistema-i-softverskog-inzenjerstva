package primer05a;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class JListTest extends JFrame {

	private static final long serialVersionUID = -8343918671420192701L;
	public JListTest() {
		setSize(500, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		c.setListData(items);

		c.addListSelectionListener(new Reakcija());

		Container cp = getContentPane();
		cp.setLayout(new FlowLayout());
		JScrollPane sp = new JScrollPane(c);
		cp.add(sp);
		cp.add(l);

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});

	}

	class Reakcija implements ListSelectionListener {
		public void valueChanged(ListSelectionEvent e) {
			l.setText(c.getSelectedValue().toString());
		}
	}

	Object[] items = { new Auto(), new Auto(false), "Treca opcija" };
	JList c = new JList(items);
	JLabel l = new JLabel("Labela");
	
	public static void main(String[] args) {
		new JListTest().setVisible(true);
	}
	
}
